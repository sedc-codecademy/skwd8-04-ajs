class Users
{
    constructor({uid, name, email})
    {
        this.uid = uid;
        this.name = name;
        this.email = email;
    }
}

module.exports = Users;
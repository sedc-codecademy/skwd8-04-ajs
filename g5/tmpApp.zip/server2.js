const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const fs = require('fs');
const Users = require('./users');

app.use(express.static('www'));
app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json());

//Middleware
app.use((req, res, next) => {
    res.setHeader('Content-Type', 'application/json');
    next();
})

app.post('/login', (req, res) => {

    let username = 'admin';
    let password = 'admin123';

    let {user, pass} = req.body;

    if(user === username && pass === password)
    res.status(200).send({"message": "Welcome"});
    else
    res.status(403).send({"message": "Wrong credentials"});
});

app.listen(3000);